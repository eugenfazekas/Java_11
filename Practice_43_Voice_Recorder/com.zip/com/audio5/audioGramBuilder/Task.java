package com.audio5.audioGramBuilder;

public interface Task {

	void makeTask();
}
