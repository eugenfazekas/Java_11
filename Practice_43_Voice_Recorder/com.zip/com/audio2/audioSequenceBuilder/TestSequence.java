package com.audio2.audioSequenceBuilder;

public class TestSequence {

	public static int[] getTestSequence() {

	int[] testSequence = new int[] {2000,100,14410,
									3000,200,14410,
									4000,300,14410,
									5000,400,14410,
									6000,500,14410};
		return testSequence;
	}
}
