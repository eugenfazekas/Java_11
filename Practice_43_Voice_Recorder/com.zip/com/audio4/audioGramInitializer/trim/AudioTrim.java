package com.audio4.audioGramInitializer.trim;

public interface AudioTrim {
	
    void buildTrimSequenceBorders(int id, int[] inputArray);
}
